<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ground" tilewidth="64" tileheight="64" spacing="16" tilecount="9" columns="3">
 <image source="../../Dungeon Tiles/Full.png" width="224" height="256"/>
</tileset>
