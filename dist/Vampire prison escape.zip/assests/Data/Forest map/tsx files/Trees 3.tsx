<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Trees" tilewidth="208" tileheight="112" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="208" height="112" source="../Trees.png"/>
 </tile>
</tileset>
