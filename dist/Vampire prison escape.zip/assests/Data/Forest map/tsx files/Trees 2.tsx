<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Trees 2" tilewidth="80" tileheight="100" spacing="16" tilecount="2" columns="2">
 <image source="../Trees.png" width="208" height="112"/>
</tileset>
