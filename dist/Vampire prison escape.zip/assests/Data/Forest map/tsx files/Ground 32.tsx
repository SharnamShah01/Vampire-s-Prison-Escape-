<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ground 32" tilewidth="16" tileheight="16" spacing="16" tilecount="12" columns="4">
 <image source="../GrassNDirt.png" width="128" height="80"/>
</tileset>
