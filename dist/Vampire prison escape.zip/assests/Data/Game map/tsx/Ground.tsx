<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ground" tilewidth="128" tileheight="128" tilecount="299" columns="23">
 <image source="../../../images/tiles for map.png" width="2944" height="1664"/>
</tileset>
