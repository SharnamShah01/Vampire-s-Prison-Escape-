<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Ground smaller" tilewidth="64" tileheight="64" tilecount="1196" columns="46">
 <image source="../../../images/tiles for map.png" width="2944" height="1664"/>
</tileset>
