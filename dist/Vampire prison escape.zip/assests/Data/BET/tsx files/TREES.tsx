<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="TREES" tilewidth="208" tileheight="112" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="41" height="87" source="../../Forest map/Trees.png~"/>
 </tile>
 <tile id="1">
  <image width="82" height="105" source="../../Forest map/Trees.png~~"/>
 </tile>
 <tile id="2">
  <image width="208" height="112" source="../../Forest map/Trees.png~~~"/>
 </tile>
</tileset>
