<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="RocksnStumps" tilewidth="16" tileheight="16" spacing="16" tilecount="4" columns="2">
 <image source="../../Forest map/RocksnStumps.png" width="64" height="64"/>
</tileset>
