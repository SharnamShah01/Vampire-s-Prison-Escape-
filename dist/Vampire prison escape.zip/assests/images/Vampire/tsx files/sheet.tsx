<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="sheet" tilewidth="16" tileheight="16" tilecount="210" columns="15">
 <image source="../Vampire_Sprite_Sheet_1.png" width="250" height="232"/>
</tileset>
