<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="sheet2" tilewidth="16" tileheight="16" spacing="16" tilecount="56" columns="8">
 <image source="../Vampire_Sprite_Sheet_1.png" width="250" height="232"/>
</tileset>
